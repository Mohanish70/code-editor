# React + Vite

An in-browser code editor that allows you to write and execute your code in the browser.

## Run Locally

```bash
# install dependencies

npm install

# start the dev server

npm run dev
```
